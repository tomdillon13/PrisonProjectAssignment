Imports System.Net.Http.Headers
Imports System.Net.NetworkInformation
Imports System.Security.Cryptography.X509Certificates

''' 
''' Improvements From the Prototype Solution
''' - Made use of OOP more effectively, Player class has now got subroutines & both
'''   sections of the program are now classes.  (Classes: ViewInfo, ControlPanel & Player)
''' - Binary search has been used rather than linear search. (Function SearchByName) 
''' - Insertion sort has been used rather than bubble sort. (Sub SortList)
''' - Validation has been properly implemented for ALL data that is input. 
'''   (Sub CreatePlayer, UpdatePlayer and all menus)
''' - File Handling has been fixed - can now update and delete players. (Subs WriteToFile and RefreshList)
''' - General grammatical errors have been fixed. (See Menus Generally)
''' - Program now makes it clear that you must input a player's full name. (CreatePlayer and UpdatePlayer subs)
''' - An FAQ section has been added for administrators. (FAQ Subroutine - ControlPanel class)
''' - Table view is now much clearer, with colour used to highlight information. (TableView Sub)
''' - Dyslexia-friendly mode is now included (Sub Main)
''' 

Module Module1
    ' This is effectively live version of the CSV file.  It has to be a global variable because it must be consistently loaded throughout the program, being used by all parts.
    Public PlayersList As New List(Of Player)
    'The following two variables are file paths. They are global because numerous subroutines throughout numerous classes have to refer to them.  It's easier to keep the paths
    'for file handling in one place, to avoid inconsistencies throughout the code.
    Public Path As String = "D:\PlayerData.csv"
    Public pwPath As String = "D:\AdminPass.dat"

    'Main subroutine is the first loop of the system.  It is a while loop that is only broken out of by selecting "Exit" in the menu.
    'The subroutine displays a menu that is then able to take the user to either of the two parts of the system, using a Case Statement to analyse the user input.
    Sub Main()
        'This decides whether the program launches into accessibility mode.  Is local, as it is not needed by the whole program, but will be passed onto the ViewInfo class as a
        'Property, due to it needing to change colours of the console at times.
        Dim Accessibility As Boolean = False

        While True
            If Accessibility = True Then
                Console.ForegroundColor = ConsoleColor.Blue
                Console.BackgroundColor = ConsoleColor.Yellow
            End If

            PlayersList = LoadPlayers()
            Console.Clear()
            Console.WriteLine("Please make a choice of:")
            Console.WriteLine("1. View Player Information")
            Console.WriteLine("2. Administrator Control Panel")
            Console.WriteLine("3. Preferences")
            Console.WriteLine("4. Exit the System")
            Console.Write(": ")
            Dim Choice As String = Console.ReadLine 'Local variable as it simply dictates what menu choice has been chosen.
            Select Case Choice
                Case "1"
                    Dim View As New ViewInfo 'Creating new instance of ViewInfo object.  Is an object for improved (at least theoretically) memory efficiency.
                    View.Accessibility = Accessibility 'Passing through accessibility settings as a property.  Not needed by other classes, so better to do it this way.
                    View.Menu() 'Sends user to the menu of the ViewInfo section.
                Case "2"
                    Console.Clear()
                    Console.WriteLine("The Control Panel is an administrator-only section.")
                    Console.Write("Password: ")
                    Dim pw As String = Console.ReadLine() 'Local variable, only acts as a temporary user input.  Removed from memory as soon as it is no longer needed.

                    Dim objSR As New IO.StreamReader(pwPath) 'Opening a new instance of the Admin Password data file.  Local as it will be closed after permissions check. 
                    If pw = objSR.ReadLine Then
                        Dim Control As New ControlPanel 'Creating a new instance of the ControlPanel object.  Is an object for (at least theoretical) improved memory efficiency.
                        objSR.Close()
                        Control.Menu()
                    Else
                        Console.WriteLine("Incorrect password.")
                        Console.ReadLine()
                        objSR.Close()
                    End If

                Case "3"
                    Console.Clear()
                    Console.WriteLine("1. Dyslexia-Friendly Mode")
                    Console.WriteLine("2. Go Back")
                    Dim Pref As String = Console.ReadLine() 'Local variable due to it simply being a menu option.
                    Select Case Pref
                        Case "1"
                            If Accessibility = False Then
                                Accessibility = True
                            Else
                                Accessibility = False
                            End If
                        Case "2"
                            Console.WriteLine("Returning to Menu")
                        Case Else
                            Console.WriteLine("Invalid input, returning to menu.")
                            Console.ReadLine()
                    End Select
                Case "4"
                    End
                Case Else
                    Console.WriteLine("Invalid input.  Please Try again.")
                    Console.ReadLine()
            End Select
        End While
    End Sub

    'The Control Panel class can be instantiated to display the administration part of the system.  It presents a menu, where the user can choose to Create, Delete or Update
    'A player.  This meets these three objectives, of course, because it allows for the creating, deleting and updating of player information. 
    Class ControlPanel
        'The Menu subroutine is the main menu of the ControlPanel code, allowing access to all 4 parts of this area of the system.
        'As with any menu in the system, it operates using a case-statement.
        Public Sub Menu()
            While True 'A while loop ensures that the menu is not broken out of until the user specifically requests it to be. 
                Console.Clear()
                Console.WriteLine("Welcome To the Control Panel")
                Console.WriteLine("1. Create a player")
                Console.WriteLine("2. Update an existing player")
                Console.WriteLine("3. Delete a player")
                Console.WriteLine("4. FAQ - Administrators")
                Console.WriteLine("5. Go Back To Menu")
                Console.Write("Please make a selection: ")
                Dim Selection As String = Console.ReadLine 'Local variable as it is only a menu option.
                Select Case Selection
                    Case "1"
                        'Create an instance of a player object, and then call the CreatePlayer subroutine within this object to give it properties.
                        Dim CreatedPlayer As New Player 'New Instance of the player object, this object will be written to the PlayersList.
                        CreatedPlayer.CreatePlayer()
                    Case "2"
                        Dim Index As Integer 'Local variable as it will be disregarded once the player is updated.  Stores the index of the searched for player in PlayersList.
                        Console.Clear()
                        Console.WriteLine("Please enter a player to update: ")
                        Try
                            'Search for a player name, and then call the subroutine inside of this player object that updates the player.
                            Index = SearchByName(Console.ReadLine)
                            PlayersList(Index).UpdatePlayer(False, "0")
                        Catch ex As Exception
                            Console.ReadLine()
                            Menu()
                        End Try

                    Case "3"
                        Dim Index As Integer 'Local variable as it will be disregarded once the player is updated. Stores the index of the searched for player in PlayersList.
                        Console.Clear()
                        Console.WriteLine("Please enter a player to Delete: ")
                        Try
                            'Searches for a player and then calls the DeletePlayer subroutine within the ControlPanel class.
                            Index = SearchByName(Console.ReadLine)
                            DeletePlayer(Index)

                        Catch ex As Exception
                            Console.ReadLine()
                            Menu()
                        End Try
                    Case "4"
                        FAQ()
                    Case "5"
                        Console.WriteLine("Returning to menu")
                        Exit Sub
                    Case Else
                        Console.WriteLine("Invalid Input.  Please try again")
                        Console.ReadLine()
                        Menu()
                End Select
            End While
        End Sub

        'Player deletion meets the "Delete players who have since left the team" objective.  It has to be outside of the Player Class because you cannot remove a player object
        'From the player list whilst within that player object, it would not make much sense. 
        Sub DeletePlayer(PlayerToDelete As Integer)
            PlayersList.Remove(PlayersList(PlayerToDelete))
            RefreshList()
        End Sub

        Sub FAQ()
            'Basically just a text-output menu, no complex code here.
            Console.Clear()
            Console.WriteLine("1. I have two players with the same name, what do I do?")
            Console.WriteLine("You are advised to include a middle name in this scenario.  For example 'Joe H. Bloggs' rather than 'Joe Bloggs'.")
            Console.WriteLine("In the unlikely scenario this does not fix the problem, you may choose to include a number at the end of the name.")

            Console.WriteLine()

            Console.WriteLine("This FAQ is by no means exhaustive and may be added to in future builds.")
            Console.ReadLine()
            Menu()
        End Sub

    End Class

    'The View Info class can be instantiated to display the non-administrative part of the system.  It presents a menu where the user can choose to View a single player's information
    'Or an overview of all of the player information within the system.
    Class ViewInfo
        Property Accessibility As Boolean 'Property stores accessibility settings from the main subroutine.  Used to return to Dyslexia-Friendly colour scheme after colour highlighting.
        'Menu subroutine offers navigation options into either displaying of a single stat or the table view.
        Public Sub Menu()
            While True 'While loop prevents the subroutine from ending until explicitly called for by the user.
                Console.Clear()

                Console.WriteLine("Welcome to PCC Stats Viewer")
                Console.WriteLine("1. Table View")
                Console.WriteLine("2. Search for a Player")
                Console.WriteLine("3. Back to Menu")

                Dim selection As String = Console.ReadLine 'Local variable as it is only a menu option. 
                Select Case selection
                    Case "1"
                        Console.Clear()
                        TableView()
                    Case "2"
                        Console.Clear()
                        DisplaySingleStat()
                    Case "3"
                        Console.WriteLine("Returning To menu.")
                        Exit Sub
                    Case Else
                        Console.WriteLine("Invalid input.")
                        Console.ReadLine()
                End Select
            End While

        End Sub

        'Table View asks the user what information to sort by and then gives an overview of all information stored in the system in a table-like format.
        'This subroutine meets the "display player information in a table-like format" objective.
        Sub TableView()
            Console.Clear()

            'Code for deciding what to sort by.
            Console.WriteLine("1. Player Name")
            Console.WriteLine("2. Batting Average")
            Console.WriteLine("3. Bowling Average")
            Console.Write("Please select one to sort by: ")
            Try
                Dim SortChoice As Integer = Console.ReadLine() 'Local variable as it is only a menu option. 
                SortList(SortChoice)
            Catch ex As Exception
                Console.WriteLine("Please input an INTEGER that is between 1 and 3.")
                TableView()
                Exit Sub
            End Try

            'Code for displaying the player information.
            Console.Clear()
            Console.WriteLine("........................................................................................................")
            For x = 0 To PlayersList.Count - 1
                Console.ForegroundColor = ConsoleColor.Red
                Console.Write("{0} ({1}YO) - {2}:  ", PlayersList(x).PlayerName, PlayersList(x).PlayerAge, PlayersList(x).PlayerRole)
                If Accessibility = True Then
                    Console.ForegroundColor = ConsoleColor.Blue
                Else
                    Console.ForegroundColor = ConsoleColor.White
                End If
                Console.Write("{0} BAT (BF:{1}, RS:{2}, TO:{3}, SR:{4}) &", PlayersList(x).BattingAverage, PlayersList(x).BallsFaced, PlayersList(x).RunsScored, PlayersList(x).TimesOut, PlayersList(x).StrikeRate)
                Console.Write(" {0} BOWL (OB:{1}, FIG:{2}/{3}, EC:{4})", PlayersList(x).BowlingAverage, PlayersList(x).OversBowled, PlayersList(x).WicketsTaken, PlayersList(x).RunsConc, PlayersList(x).BowlingEconomy)
                Console.WriteLine()
            Next
            Console.WriteLine("........................................................................................................")
            Console.ReadLine()
        End Sub

        'Display Single Stat searches for a player that was input by the user, and then displays his statistics in a plain-english, readable form - like a summary.
        'It meets the searching for a player objective as well as the recommending training objective. 
        Sub DisplaySingleStat()
            Try
                Console.Clear()
                Console.Write("Please enter a player name To display: ")
                Dim NameToSearch As String = Console.ReadLine()
                Dim index As Integer = SearchByName(NameToSearch)
                Dim SearchedPlayer As Player = PlayersList(index)

                Console.WriteLine()
                Console.WriteLine("Player Name: {0}", SearchedPlayer.PlayerName)
                Console.WriteLine("{0} Years Old {1}", SearchedPlayer.PlayerAge, SearchedPlayer.PlayerRole)

                Console.WriteLine()
                Console.WriteLine("--Batting Statistics--")
                Console.WriteLine("Averages {0} at a Strike Rate of {1}", SearchedPlayer.BattingAverage, SearchedPlayer.StrikeRate)
                Console.WriteLine("Has scored {0} runs off {1} balls, being out {2} times", SearchedPlayer.RunsScored, SearchedPlayer.BallsFaced, SearchedPlayer.TimesOut)

                Console.WriteLine()
                Console.WriteLine("--Bowling Figures--")
                Console.WriteLine("Averages {0} with an economy of {1}", SearchedPlayer.BowlingAverage, SearchedPlayer.BowlingEconomy)
                Console.WriteLine("Has bowled {0} overs and conceded {1} runs", SearchedPlayer.OversBowled, SearchedPlayer.RunsConc)
                Console.WriteLine("Has taken {0} wickets", SearchedPlayer.WicketsTaken)

                Console.WriteLine()

                If SearchedPlayer.BattingAverage < SearchedPlayer.BowlingAverage And SearchedPlayer.BowlingAverage > 30 Then
                    Console.WriteLine("Bowling is likely weakness for this player.")
                    Console.WriteLine("This area should be worked on.")

                ElseIf SearchedPlayer.BattingAverage < SearchedPlayer.BowlingAverage And SearchedPlayer.BattingAverage < 30 Then
                    Console.WriteLine("Batting is likely weakness for this player.")
                    Console.WriteLine("This area should be worked on.")

                Else
                    Console.WriteLine("We believe this player to be pretty decent all-round.")
                End If
            Catch
                Console.ReadLine()
                DisplaySingleStat()
            End Try
            Console.ReadLine()
        End Sub

    End Class

    'Create Player class holds all player data pertaining to an individual object, and methods for handling of each object's data.
    Class Player
        'The following are properties because they are statistics that pertain to each instance of a player object.
        'Being a global property, they can be called by any part of the program (which is neccessary when being inside of a global array called by all parts of the program).
        Public Property PlayerName As String 'Property stores the name of the player.
        Public Property PlayerRole As String 'Property stores the role of the player.
        Public Property PlayerAge As Integer 'Property stores the age of the player.
        Public Property BallsFaced As Integer 'Property stores the Balls Faced by the player.
        Public Property RunsScored As Integer 'Property stores the Runs Scored by the player.
        Public Property TimesOut As Integer 'Property stores the times the player has been out.
        Public Property OversBowled As Integer 'Property Stores the Overs Bowled by the player.
        Public Property RunsConc As Integer 'Property stores the Runs Conceded by the player.
        Public Property WicketsTaken As Integer 'Property stores the Wickets Taken by the player.

        Public Property StrikeRate As Decimal 'Property stores the strike rate of a player.  Real because it is from a division calculation that might not be a whole number. 
        Public Property BattingAverage As Decimal 'Property stores the Batting average of a player.  Real because it is from a division calculation that might not be a whole number. 
        Public Property BowlingAverage As Decimal 'Property stores the Bowling average of a player.  Real because it is from a division calculation that might not be a whole number. 
        Public Property BowlingEconomy As Decimal 'Property stores the Bowling economy of a player.  Real because it is from a division calculation that might not be a whole number. 

        Public Sub CreatePlayer()
            'Allows user to enter player data and create a new 'Player Object' in the list.

            Console.Clear()

            Console.WriteLine("First, we need the player's personal information.")
            Console.Write("Player FULL Name (E.G Joe Bloggs): ")
            PlayerName = Console.ReadLine

            Console.WriteLine("----------")

            'Menu option is used to ensure that player type takes certain form.
            Console.WriteLine("1. Batter")
            Console.WriteLine("2. Bowler")
            Console.WriteLine("3. Allrounder")
            Console.Write("Player Role: ")
            Dim choice As String = Console.ReadLine() 'Local variable as it is only a menu option.
            Select Case choice
                Case "1"
                    PlayerRole = "Batter"
                Case 2
                    PlayerRole = "Bowler"
                Case 3
                    PlayerRole = "Allrounder"
                Case Else
                    Console.WriteLine("Invalid input.  Please try again.")
                    Console.ReadLine()
                    CreatePlayer()
            End Select

            Console.WriteLine("----------")

            Try 'Try-Except loop acts as a catch-all clause. If any of the following are incorrect, the system will reject the input and throw an error message.  Type check.
                Console.Write("Player Age: ")
                PlayerAge = Console.ReadLine

                Console.WriteLine("Now, we need his BATTING statistics.")
                Console.Write("Balls Faced: ")
                BallsFaced = Console.ReadLine
                Console.Write("Runs Scored: ")
                RunsScored = Console.ReadLine
                Console.Write("Times Out: ")
                TimesOut = Console.ReadLine

                Console.WriteLine("Finally, we need the BOWLING statistics.")
                Console.Write("Overs Bowled: ")
                OversBowled = Console.ReadLine
                Console.Write("Runs conceded: ")
                RunsConc = Console.ReadLine
                Console.Write("Wickets Taken: ")
                WicketsTaken = Console.ReadLine
            Catch ex As Exception
                Console.WriteLine("Failed to validate integer inputs.  Please ensure all inputs entered are integers.")
                Console.WriteLine("Error: {0}", ex)
                Console.ReadLine()
                CreatePlayer()
            End Try

            If Validation(False) = True Then 'Validation subroutine runs validation on the strings, primarily.
                Console.WriteLine("Please try again.")
                Console.ReadLine()
                CreatePlayer()
                Exit Sub
            End If

            Try 'Third and final stage of validation - if stats are calculated correctly, all integers are fine.
                Stats()
            Catch ex As Exception
                Console.WriteLine("There was an error calculating statistics.")
                Console.WriteLine("It is likely that there was an impossible calculation, for example a division by 0.")
                Console.WriteLine("Error: {0}", ex)
                Console.ReadLine()
                CreatePlayer()
                Exit Sub
            End Try

            WriteToFile(True)
            PlayersList = LoadPlayers() 'Refreshing the list.
        End Sub

        Public Sub UpdatePlayer(failedValidation As Boolean, Choice As String) ' Validation has been completed, no need to return
            'Subroutine for updating the player object.
            'Satisfies the keeping of player data updated objective.
            'Effectively, a menu which allows for updating of any individual statistic.

            Dim Temp As Integer 'Local variable will be disregarded after subroutine has been used.  Stores the current data in case the validation fails, and data has to be reset.
            Console.Clear()
            If failedValidation = False Then
                Console.WriteLine("Please make a choice of:")
                Console.WriteLine("1. Player Name")
                Console.WriteLine("2. Player Age")
                Console.WriteLine("3. Player Role")
                Console.WriteLine("--- Batting Figures ---")
                Console.WriteLine("4. Balls Faced")
                Console.WriteLine("5. Runs Scored")
                Console.WriteLine("6. Times Out")
                Console.WriteLine("--- Bowling Figures ---")
                Console.WriteLine("7. Runs Conceded")
                Console.WriteLine("8. WicketsTaken")
                Console.WriteLine("9. Overs Bowled")
                Console.WriteLine("---------------")
                Console.WriteLine("10. Return to main menu")
                Choice = Console.ReadLine()
                Console.Clear()
            End If

            Select Case Choice
                Case "1"
                    Console.WriteLine("Player Name is currently: {0}", PlayerName)
                    Console.Write("New Player FULL Name: ")
                    PlayerName = Console.ReadLine()
                    If Validation(True) = True Then
                        Console.WriteLine("Please Try Again.")
                        Console.ReadLine()
                        UpdatePlayer(True, "1")
                        Exit Sub
                    End If

                Case "2"
                    Console.WriteLine("Player Age is currently: {0}", PlayerAge)
                    Console.Write("New Player Age: ")
                    Try
                        PlayerAge = Console.ReadLine()
                        If Validation(True) = True Then
                            PlayerAge = "INVALID"
                        End If
                    Catch ex As Exception
                        Console.WriteLine("There was an error.  Player Age must be an integer between 15 and 100 inclusive.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        UpdatePlayer(True, "2")
                        Exit Sub
                    End Try
                Case "3"
                    Console.WriteLine("Player Role is currently: {0}", PlayerRole)
                    Console.WriteLine("1: Batter")
                    Console.WriteLine("2: Bowler")
                    Console.WriteLine("3: Allrounder")
                    Dim Role As String = Console.ReadLine() 'Local variable as this is only a menu option. 
                    Select Case Role
                        Case "1"
                            PlayerRole = "Batter"
                        Case "2"
                            PlayerRole = "Bowler"
                        Case "3"
                            PlayerRole = "Allrounder"
                        Case Else
                            Console.WriteLine("Invalid input.")
                            Console.ReadLine()
                            UpdatePlayer(True, "3")
                            Exit Sub
                    End Select

                Case "4"
                    Temp = BallsFaced
                    Console.WriteLine("Current Balls faced: {0}", BallsFaced)
                    Console.Write("Amount to Add: ")
                    Try
                        BallsFaced += Console.ReadLine()
                        Stats()
                    Catch ex As Exception
                        Console.WriteLine("There was an error with the new data.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        BallsFaced = Temp
                        UpdatePlayer(True, "4")
                        Exit Sub
                    End Try

                Case "5"
                    Temp = RunsScored
                    Console.WriteLine("Current Runs Scored: {0}", RunsScored)
                    Console.Write("Amount to Add: ")
                    Try
                        RunsScored += Console.ReadLine()
                        Stats()
                    Catch ex As Exception
                        Console.WriteLine("There was an error with the new data.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        RunsScored = Temp
                        UpdatePlayer(True, "5")
                        Exit Sub
                    End Try

                Case "6"
                    Temp = TimesOut
                    Console.WriteLine("Current TimesOut: {0}", TimesOut)
                    Console.Write("Amount to Add: ")
                    Try
                        TimesOut += Console.ReadLine()
                        Stats()
                    Catch ex As Exception
                        Console.WriteLine("There was an error with the new data.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        TimesOut = Temp
                        UpdatePlayer(True, "6")
                        Exit Sub
                    End Try

                Case "7"
                    Temp = RunsConc
                    Console.WriteLine("Current Runs Conceded: {0}", RunsConc)
                    Console.Write("Amount to Add: ")
                    Try
                        RunsConc += Console.ReadLine()
                        Stats()
                    Catch ex As Exception
                        Console.WriteLine("There was an error with the new data.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        RunsConc = Temp
                        UpdatePlayer(True, "7")
                        Exit Sub
                    End Try

                Case "8"
                    Temp = WicketsTaken
                    Console.WriteLine("Current Wickets Taken: {0}", WicketsTaken)
                    Console.Write("Amount to Add: ")
                    Try
                        WicketsTaken += Console.ReadLine()
                        Stats()
                    Catch ex As Exception
                        Console.WriteLine("There was an error with the new data.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        WicketsTaken = Temp
                        UpdatePlayer(True, "8")
                        Exit Sub
                    End Try

                Case "9"
                    Temp = OversBowled
                    Console.WriteLine("Current Overs Bowled: {0}", OversBowled)
                    Console.Write("Amount to Add: ")
                    Try
                        OversBowled += Console.ReadLine()
                        Stats()
                    Catch ex As Exception
                        Console.WriteLine("There was an error with the new data.")
                        Console.WriteLine("Error: {0}", ex)
                        Console.ReadLine()
                        OversBowled = Temp
                        UpdatePlayer(True, "9")
                        Exit Sub
                    End Try

                Case "10"
                    Main()
            End Select

            RefreshList()

        End Sub

        Public Sub WriteToFile(DontClearFile As Boolean)
            'This subroutine simply goes through all variables and writes them to a line in the file.
            'Satisfies file handling objectives.
            Dim objSW As IO.StreamWriter 'New instance of the stream writer, local as it will close once the subroutine has finished. 
            objSW = New IO.StreamWriter(Path, DontClearFile)

            objSW.Write(PlayerName & ",")
            objSW.Write(PlayerAge & ",")
            objSW.Write(PlayerRole & ",")

            objSW.Write(BallsFaced & ",")
            objSW.Write(RunsScored & ",")
            objSW.Write(TimesOut & ",")

            objSW.Write(RunsConc & ",")
            objSW.Write(WicketsTaken & ",")
            objSW.Write(OversBowled & ",")

            objSW.Write(StrikeRate & ",")
            objSW.Write(BattingAverage & ",")
            objSW.Write(BowlingAverage & ",")
            objSW.Write(BowlingEconomy & ",")

            objSW.WriteLine()
            objSW.Close()
        End Sub

        Function Validation(Update As Boolean)
            'Validation of PlayerName and PlayerAge.

            Dim isError = False 'Local variable that will be returned, to decide the result of the validation.  Basically an error without VB physically throwing an erorr. 
            If PlayerName = "" Then 'Not a null value. (Presence check avoiding failure of search)
                Console.WriteLine("Player name must not be set to a null value.")
                isError = True
            End If

            If Update = False Then 'Only need to throw an error if PlayerName already exists in list if we aren't coming from the update subroutine.  Also a form of presence check, avoiding two duplicate items.
                Try
                    Console.WriteLine(PlayersList(SearchByName(PlayerName)).PlayerName)
                    Console.WriteLine("Player Name exists already, please try again.")
                    Console.WriteLine("Can you try adding a middle name or number on the end?")
                    isError = True
                Catch ex As Exception 'In this case, there is only a success if an error has been found because the search fails.
                    Console.WriteLine("Validation successful.")
                End Try
            End If

            If PlayerAge < 15 Or PlayerAge > 100 Then 'Simple range check on the player data.
                Console.WriteLine("Player age must be between 15 and 100 inclusive.")
                isError = True
            End If
            Return isError
        End Function

        Sub Stats()
            'Calculations of Strike Rate, economy, and averages.
            If RunsScored = 0 And BallsFaced = 0 Then ' Cannot divide by 0 so if 0 is detected, calculation isn't run.
                StrikeRate = 0
            Else
                StrikeRate = (RunsScored * 100) / BallsFaced 'Shows how many runs are scored per one-hundred balls.
            End If

            If TimesOut = 0 Then ' Cannot divide by 0 so if 0 is detected, calculation isn't run.
                BattingAverage = 0
            Else
                BattingAverage = RunsScored / TimesOut 'Average runs scored per times out.
            End If

            If WicketsTaken = 0 Then ' Cannot divide by 0 so if 0 is detected, calculation isn't run.
                BowlingAverage = 0
            Else
                BowlingAverage = RunsConc / WicketsTaken 'Average runs conceded per wickets taken.
            End If

            If OversBowled = 0 Then ' Cannot divide by 0 so if 0 is detected, calculation isn't run.
                BowlingEconomy = 0
            Else
                BowlingEconomy = RunsConc / OversBowled 'Average runs conceded per overs bowled.
            End If
        End Sub

    End Class

    'Sorting
    'Using an insertion sort algorithm, the program sorts either by PlayerName, Batting Average or Bowling average - depending on what parameter has been passed into the subroutine.
    'This meets the "Sort the information by various metrics" objective. 
    Sub SortList(selection As Integer)
        '1. Player Name 
        '2. Batting Average 
        '3. Bowling Average
        Dim y As Integer 'Local variable used exclusively during the insertion sort.  This is used to store the index of the point directly "behind" our marker point.
        Dim Temp As Player 'Temp variable is local as it will be disregarded at the end of the sort.  Stores the player object temporarily so that it can be swapped. 

        Select Case selection 'Selection of which metric to sort by, as annotated above.
            Case 1
                For x = 0 To PlayersList.Count - 1
                    y = x - 1
                    While y >= 0
                        If PlayersList(y).PlayerName > PlayersList(x).PlayerName Then 'A Swap is made if PlayerName at Y is greater than at X.
                            Temp = PlayersList(x)
                            PlayersList(x) = PlayersList(y)
                            PlayersList(y) = Temp
                            y -= 1
                        Else
                            Exit While
                        End If
                    End While
                Next
            Case 2
                For x = 0 To PlayersList.Count - 1
                    y = x - 1
                    While y >= 0
                        If PlayersList(y).BattingAverage > PlayersList(x).BattingAverage Then 'A Swap is made if PlayerName at Y is greater than at X.
                            Temp = PlayersList(x)
                            PlayersList(x) = PlayersList(y)
                            PlayersList(y) = Temp
                            y -= 1
                        Else
                            Exit While
                        End If
                    End While
                Next
            Case 3
                For x = 0 To PlayersList.Count - 1
                    y = x - 1
                    While y >= 0
                        If PlayersList(y).BowlingAverage > PlayersList(x).BowlingAverage Then 'A Swap is made if PlayerName at Y is greater than at X.
                            Temp = PlayersList(x)
                            PlayersList(x) = PlayersList(y)
                            PlayersList(y) = Temp
                            y -= 1
                        Else
                            Exit While
                        End If
                    End While
                Next
        End Select
    End Sub

    'Subroutine loads all of the players from the CSV into the "live" version that is the Array. 
    'This half-meets the "data should be stored in an external file" objective, as it enables the program to read from the file. 
    Function LoadPlayers()
        'The following are local variables as they are only used by this subroutine. 
        Dim objSR As New IO.StreamReader(Path) 'New instance of stream-reader that opens the PlayerData.csv file
        Dim rawPlayer As String 'The raw data from a line of the CSV file.
        Dim rawPlayerArr() As String 'Stores a formatted version of the line from the CSV file, which can then turned into a Player Object.
        Dim Players As New List(Of Player) 'An array that stores the retreived, formatted, players from the file.
        rawPlayer = objSR.ReadLine

        Do While Not rawPlayer Is Nothing
            rawPlayerArr = rawPlayer.Split(",")
            Players.Add(New Player() With {.PlayerName = rawPlayerArr(0), .PlayerAge = rawPlayerArr(1), .PlayerRole = rawPlayerArr(2), .BallsFaced = rawPlayerArr(3), .RunsScored = rawPlayerArr(4), .TimesOut = rawPlayerArr(5), .RunsConc = rawPlayerArr(6), .WicketsTaken = rawPlayerArr(7), .OversBowled = rawPlayerArr(8), .StrikeRate = rawPlayerArr(9), .BattingAverage = rawPlayerArr(10), .BowlingAverage = rawPlayerArr(11), .BowlingEconomy = rawPlayerArr(12)})
            rawPlayer = objSR.ReadLine
        Loop
        objSR.Close()
        Return Players
    End Function

    'Searching
    'Using a binary search algorithm, the program searches by PlayerName and returns the index of this player in the array.
    Function SearchByName(ByVal Key As String)
        SortList(1)

        'Local variables that are only used by the SearchByName function, and can be removed from memory when it is finished.
        Dim found As Boolean = False 'The terminating condition of the while loop signifiying a successful search.
        '
        Dim first As Integer = 0 'A pointer to the first item that is looked at, stored as an index of the list.
        Dim last As Integer = PlayersList.Count - 1 'A pointer to the last item that is looked at, stored as an index of the list.

        Dim midpoint As Integer 'The midpoint, what is actually compared against the key. 

        Dim Iterations As Integer = 0 'Serves no functional purpose but to brag about how efficient the binary search is.

        While first <= last And found = False 'Loop terminates when either item is found or the list runs out.
            Iterations += 1
            midpoint = (first + last) / 2 'Calculating the mid point as the sum of the first and last pointers divided by two.
            If PlayersList(midpoint).PlayerName = Key Then 'If the midpoint matches the key, found is 'true'.
                found = True
                Console.WriteLine("Search finished in {0} iterations.", Iterations)
                Return midpoint 'Returning the midpoint gives the index of the found item in the list.
            ElseIf PlayersList(midpoint).PlayerName < Key Then
                first = midpoint + 1 'If PlayerName at the midpoint is less than the key, disregard everything to the left of the midpoint.
            Else
                last = midpoint - 1 'If PlayerName at the midpoint is greater than the key, disregard everything to the right of the midpoint.
            End If
        End While

        Console.WriteLine("Player Not Found")
        Return 1000 'Returning a large number that would be out of the index of any list, as to produce an error.
    End Function

    Sub RefreshList()
        'Subroutine for ensuring that player data is consistent between 'live' array and the CSV.
        For x = 0 To PlayersList.Count 'Iterate through the list, writing each player object to the CSV.
            If x = 0 Then 'File only needs to be wiped on the first iteration.
                PlayersList(x).WriteToFile(False)
            Else
                PlayersList(x).WriteToFile(True)
            End If

        Next
        PlayersList = LoadPlayers() 'Refresh the list to ensure everything is consistent.
    End Sub

End Module
