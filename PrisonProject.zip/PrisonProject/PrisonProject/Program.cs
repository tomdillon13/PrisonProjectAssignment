﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrisonProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ward wardA = new Ward();
            wardA.cells = 30;
            wardA.maxPrisoners = 2;

            Ward wardB = new Ward();
            wardB.cells = 40;
            wardB.maxPrisoners = 3;

        }

        public class Ward
        {
            public int maxPrisoners;
            public int cells;
            public List<Prisoner> prisoners = new List<Prisoner>();
            string Warden;

            public void Menu()
            {

            }

            public void AddPrisoner()
            {
                if (prisoners.Count >= maxPrisoners * cells)
                {
                    Console.Clear();
                    Console.WriteLine("This ward is at Capacity, please try again.");
                    Console.ReadLine();
                }
                else
                {
                    Prisoner temp = new Prisoner();
                    temp.enterInformation();
                    prisoners.Add(temp);
                }
            }


        }

        public class Prisoner : Ward
        {
            string prisonerID;
            string prisonerName;
            string[] additionalDuties;
            Boolean lockedDown;

            public void enterInformation()
            {
                Console.Clear();
                Console.Write("Prisoner ID: ");
                prisonerID = Console.ReadLine();
                Console.Write("Prsoner Name: ");
                prisonerName = Console.ReadLine();
                Console.WriteLine("Prisoner successfully added.");
                Console.ReadLine();
                Menu();
            }

            public void AddDuty()
            {

            }

            public void lockdown()
            {
                Console.Clear();
                Console.WriteLine("{0} Locked Down: {1}", prisonerName, lockedDown);
                Console.Write("Do you want to change this (y/n): ");
                string opt = Console.ReadLine();
                if (opt == "y")
                {
                    lockedDown = !lockedDown;
                    Console.WriteLine("Prisoner status changed.");
                    Console.ReadLine();
                }
                else if(opt=="n")
                {
                    Console.WriteLine("Returning to menu.");
                    Console.ReadLine();
                }
            }
        }


    }
}
